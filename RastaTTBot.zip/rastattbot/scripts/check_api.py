"""Step 1 smoke test: prove the Soroush Plus Bot API works with your token.

Run on the server that will host the bot:
    python -m scripts.check_api

It checks, in order:
  1. getMe            -> the token is valid and the API is reachable
  2. getUpdates       -> receiving messages works (send any message to the bot)
  3. sendMessage      -> sending a message with inline buttons works
  4. callback_query   -> pressing a button reaches the bot
  5. editMessageText  -> the bot can update the message after a press
"""

import sys
import time

from bot.config import load_config
from bot.soroush_api import SoroushAPIError, SoroushClient, inline_keyboard

WAIT_SECONDS = 180


def wait_for(client: SoroushClient, offset, predicate, what: str):
    """Poll updates until predicate(update) is true; return (update, next_offset)."""
    print(f"   Waiting up to {WAIT_SECONDS}s for {what}...")
    deadline = time.monotonic() + WAIT_SECONDS
    while time.monotonic() < deadline:
        for update in client.get_updates(offset=offset, timeout=20):
            offset = update["update_id"] + 1
            if predicate(update):
                return update, offset
    raise SystemExit(f"   Timed out waiting for {what}.")


def main() -> int:
    config = load_config()
    client = SoroushClient(config.token, config.api_base)

    try:
        print("1) getMe")
        me = client.get_me()
        print(f"   OK: bot is {me.get('first_name')} (@{me.get('username')}), id={me.get('id')}")

        print("2) getUpdates — open the bot in Soroush Plus and send it any message (e.g. /start)")
        update, offset = wait_for(client, None, lambda u: "message" in u, "a message")
        chat_id = update["message"]["chat"]["id"]
        print(f"   OK: got a message from chat_id={chat_id}")

        print("3) sendMessage with inline buttons")
        sent = client.send_message(
            chat_id,
            "تست ربات حضور و غیاب\nیکی از دکمه‌ها را بزنید:",
            reply_markup=inline_keyboard([[("✅ ورود", "test:in"), ("🏁 خروج", "test:out")]]),
        )
        print(f"   OK: message_id={sent.get('message_id')}")

        print("4) callback_query — press one of the buttons in Soroush Plus")
        update, offset = wait_for(client, offset, lambda u: "callback_query" in u, "a button press")
        query = update["callback_query"]
        print(f"   OK: button data={query.get('data')!r}")
        client.answer_callback_query(query["id"], text="دریافت شد")

        print("5) editMessageText")
        client.edit_message_text(
            chat_id, sent["message_id"], f"دکمه دریافت شد: {query.get('data')}"
        )
        print("   OK")

        # Acknowledge processed updates so they are not delivered again.
        client.get_updates(offset=offset, timeout=0)
    except SoroushAPIError as exc:
        print(f"   FAILED: {exc}")
        return 1

    print("\nAll checks passed. The API supports everything the bot needs.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
