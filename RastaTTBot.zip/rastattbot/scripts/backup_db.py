"""Copy the database to backups/ with a date stamp and keep the newest 30 copies.

Safe to run while the bot is running (uses SQLite's online backup).
    python -m scripts.backup_db
"""

import glob
import os
from datetime import datetime

from bot.config import load_config
from bot.db import Database

KEEP = 30


def main() -> None:
    config = load_config()
    backup_dir = os.path.join(os.path.dirname(os.path.abspath(config.db_path)), "backups")
    os.makedirs(backup_dir, exist_ok=True)
    dest = os.path.join(backup_dir, f"attendance_{datetime.now():%Y%m%d_%H%M%S}.sqlite3")
    Database(config.db_path).backup(dest)
    print(f"backup written: {dest}")
    for old in sorted(glob.glob(os.path.join(backup_dir, "attendance_*.sqlite3")))[:-KEEP]:
        os.remove(old)


if __name__ == "__main__":
    main()
