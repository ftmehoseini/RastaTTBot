"""Persian (Jalali) calendar helpers and Persian text formatting."""

from datetime import date, datetime, timedelta

import jdatetime

MONTHS = [
    "فروردین", "اردیبهشت", "خرداد", "تیر", "مرداد", "شهریور",
    "مهر", "آبان", "آذر", "دی", "بهمن", "اسفند",
]

# Keyed by Python's date.weekday() (Monday = 0).
WEEKDAYS = {
    5: "شنبه", 6: "یکشنبه", 0: "دوشنبه", 1: "سه‌شنبه",
    2: "چهارشنبه", 3: "پنجشنبه", 4: "جمعه",
}

SATURDAY = 5
FRIDAY = 4

_DIGITS = str.maketrans("۰۱۲۳۴۵۶۷۸۹٠١٢٣٤٥٦٧٨٩", "01234567890123456789")


def normalize_digits(text: str) -> str:
    """Turn Persian and Arabic digits into ASCII digits."""
    return text.translate(_DIGITS)


def to_jalali(d: date) -> jdatetime.date:
    return jdatetime.date.fromgregorian(date=d)


def to_gregorian(year: int, month: int, day: int) -> date:
    return jdatetime.date(year, month, day).togregorian()


def days_in_month(year: int, month: int) -> int:
    if month <= 6:
        return 31
    if month <= 11:
        return 30
    return 30 if jdatetime.date(year, 1, 1).isleap() else 29


def recent_months(today: date, count: int = 3) -> list[tuple[int, int]]:
    """The current Jalali month and the ones before it, newest first."""
    j = to_jalali(today)
    year, month = j.year, j.month
    months = []
    for _ in range(count):
        months.append((year, month))
        month -= 1
        if month == 0:
            year, month = year - 1, 12
    return months


def month_label(year: int, month: int) -> str:
    return f"{MONTHS[month - 1]} {year}"


def format_date(d: date) -> str:
    j = to_jalali(d)
    return f"{WEEKDAYS[d.weekday()]} {j.day} {MONTHS[j.month - 1]} {j.year}"


def format_date_short(d: date) -> str:
    j = to_jalali(d)
    return f"{j.year}/{j.month:02d}/{j.day:02d}"


def format_time(dt: datetime) -> str:
    return dt.strftime("%H:%M")


def format_duration(td: timedelta) -> str:
    minutes = int(td.total_seconds() // 60)
    return f"{minutes // 60}:{minutes % 60:02d}"


def week_start(d: date) -> date:
    """The Saturday that starts d's Iranian week."""
    return d - timedelta(days=(d.weekday() - SATURDAY) % 7)


def month_range(d: date) -> tuple[date, date]:
    """First and last Gregorian dates of d's Jalali month."""
    j = to_jalali(d)
    first = to_gregorian(j.year, j.month, 1)
    last = to_gregorian(j.year, j.month, days_in_month(j.year, j.month))
    return first, last
