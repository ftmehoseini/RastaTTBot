"""Turns Soroush updates into actions: registration, buttons, forgotten-entry flow, reports.

Forgotten-entry flow (all inline buttons, editing one message):
    kind (in/out) -> month -> day -> hour -> minute (typed) -> confirm
The choices so far travel inside callback_data (e.g. "fg:h:out:1405:7:20:9");
only the typed-minute step needs stored state.
"""

import logging
from datetime import date, datetime, timedelta
from typing import Callable, Optional

from .attendance import Attendance, AttendanceError
from .config import Config
from .db import Database, Session
from .excel_export import build_workbook, file_name
from .jalali import (
    MONTHS,
    days_in_month,
    format_date,
    format_duration,
    format_time,
    month_label,
    month_range,
    normalize_digits,
    recent_months,
    to_gregorian,
    to_jalali,
    week_start,
)
from .reports import team_report, user_report
from .soroush_api import SoroushAPIError, SoroushClient, inline_keyboard, reply_keyboard

log = logging.getLogger(__name__)

BTN_IN = "✅ ورود"
BTN_OUT = "🏁 خروج"
BTN_FORGOT = "📝 ثبت ساعت فراموش‌شده"
BTN_REPORT = "📊 گزارش"
MAIN_MENU = reply_keyboard([[BTN_IN, BTN_OUT], [BTN_FORGOT, BTN_REPORT]])

KIND_LABEL = {"in": "ورود", "out": "خروج"}
CANCEL_ROW = [("✖️ لغو", "fg:x")]

HELP_TEXT = (
    "راهنما:\n"
    f"{BTN_IN}: ثبت ساعت ورود (همین الان)\n"
    f"{BTN_OUT}: ثبت ساعت خروج (همین الان)\n"
    f"{BTN_FORGOT}: ثبت ورود یا خروجی که فراموش شده (ماه ← روز ← ساعت ← دقیقه)\n"
    f"{BTN_REPORT}: گزارش هفته و ماه، و فایل اکسل\n\n"
    "/myid نمایش شناسه‌ی شما\n/cancel لغو عملیات جاری"
)


def stale_button(session: Session) -> dict:
    """Inline button that jumps straight to choosing the check-out hour for that day."""
    j = to_jalali(session.check_in.date())
    return inline_keyboard([[("📝 ثبت خروجِ آن روز", f"fg:d:out:{j.year}:{j.month}:{j.day}")]])


class BotHandlers:
    def __init__(
        self,
        client: SoroushClient,
        db: Database,
        config: Config,
        now: Callable[[], datetime],
    ):
        self.client = client
        self.db = db
        self.config = config
        self.now = now
        self.attendance = Attendance(db, config.max_shift_hours)

    def is_admin(self, chat_id) -> bool:
        return str(chat_id) in self.config.admin_ids

    # --- entry point -------------------------------------------------------

    def handle_update(self, update: dict) -> None:
        if "message" in update:
            self.handle_message(update["message"])
        elif "callback_query" in update:
            self.handle_callback(update["callback_query"])

    def send(self, chat_id, text: str, reply_markup: Optional[dict] = None) -> None:
        self.client.send_message(chat_id, text, reply_markup=reply_markup)

    # --- text messages -----------------------------------------------------

    def handle_message(self, message: dict) -> None:
        chat_id = message["chat"]["id"]
        text = normalize_digits((message.get("text") or "").strip())
        user = self.db.get_user(chat_id)
        state, data = self.db.get_state(chat_id)

        if text == "/myid":
            self.send(chat_id, f"شناسه‌ی شما: {chat_id}")
            return
        if text in ("/cancel", "لغو"):
            self.db.clear_state(chat_id)
            self.send(chat_id, "لغو شد.", MAIN_MENU)
            return
        if text == "/help":
            self.send(chat_id, HELP_TEXT, MAIN_MENU)
            return

        if not user:
            if state == "await_name" and text and not text.startswith("/"):
                self._register(chat_id, text)
            else:
                self.db.set_state(chat_id, "await_name")
                self.send(chat_id, "سلام! به ربات حضور و غیاب خوش آمدید.\nلطفاً نام و نام خانوادگی خود را بنویسید:")
            return

        if text == "/start":
            self.db.clear_state(chat_id)
            self.send(chat_id, f"سلام {user.full_name}!\n\n{HELP_TEXT}", MAIN_MENU)
            return

        if text in (BTN_IN, BTN_OUT, BTN_FORGOT, BTN_REPORT):
            self.db.clear_state(chat_id)
            if text == BTN_IN:
                self._check_in(chat_id)
            elif text == BTN_OUT:
                self._check_out(chat_id)
            elif text == BTN_FORGOT:
                self.send(chat_id, "کدام را فراموش کرده‌اید؟", inline_keyboard([
                    [("ورود", "fg:k:in"), ("خروج", "fg:k:out")], CANCEL_ROW,
                ]))
            else:
                self._report_menu(chat_id)
            return

        if state == "await_minute":
            self._minute_entered(chat_id, text, data)
            return

        self.send(chat_id, "لطفاً از دکمه‌های پایین صفحه استفاده کنید.", MAIN_MENU)

    def _register(self, chat_id, name: str) -> None:
        name = " ".join(name.split())
        if not 3 <= len(name) <= 60:
            self.send(chat_id, "نام باید بین ۳ تا ۶۰ حرف باشد. دوباره بنویسید:")
            return
        self.db.upsert_user(chat_id, name, self.now())
        self.db.clear_state(chat_id)
        self.send(chat_id, f"✅ {name} عزیز، ثبت‌نام شما انجام شد.\n\n{HELP_TEXT}", MAIN_MENU)

    # --- check-in / check-out ----------------------------------------------

    def _send_error(self, chat_id, err: AttendanceError) -> None:
        self.send(chat_id, err.message, stale_button(err.stale) if err.stale else MAIN_MENU)

    def _check_in(self, chat_id) -> None:
        now = self.now()
        try:
            session = self.attendance.check_in(chat_id, now)
        except AttendanceError as err:
            self._send_error(chat_id, err)
            return
        self.send(chat_id, f"✅ ورود ثبت شد: {format_date(now.date())} ساعت {format_time(session.check_in)}", MAIN_MENU)

    def _check_out(self, chat_id) -> None:
        now = self.now()
        try:
            session = self.attendance.check_out(chat_id, now)
        except AttendanceError as err:
            self._send_error(chat_id, err)
            return
        self.send(
            chat_id,
            f"🏁 خروج ثبت شد: ساعت {format_time(session.check_out)}\n"
            f"مدت حضور: {format_duration(session.duration)}",
            MAIN_MENU,
        )

    # --- callbacks ---------------------------------------------------------

    def handle_callback(self, query: dict) -> None:
        data = query.get("data") or ""
        message = query.get("message") or {}
        chat_id = message.get("chat", {}).get("id") or query["from"]["id"]
        message_id = message.get("message_id")
        try:
            self.client.answer_callback_query(query["id"])
        except SoroushAPIError as exc:
            log.warning("answerCallbackQuery failed: %s", exc)

        if not self.db.get_user(chat_id):
            self.send(chat_id, "اول با /start ثبت‌نام کنید.")
            return

        parts = data.split(":")
        if parts[0] == "fg":
            self._forgot_callback(chat_id, message_id, parts[1:])
        elif parts[0] == "rp":
            self._report_callback(chat_id, parts[1:])

    def _edit(self, chat_id, message_id, text: str, markup: Optional[dict] = None) -> None:
        """Edit the flow message in place; fall back to a new message if editing fails."""
        if message_id is not None:
            try:
                self.client.edit_message_text(chat_id, message_id, text, reply_markup=markup)
                return
            except SoroushAPIError as exc:
                log.info("editMessageText failed, sending new message: %s", exc)
        self.send(chat_id, text, markup)

    # --- forgotten-entry flow ----------------------------------------------

    def _forgot_callback(self, chat_id, message_id, parts: list[str]) -> None:
        step = parts[0] if parts else ""
        today = self.now().date()
        try:
            if step == "x":
                self.db.clear_state(chat_id)
                self._edit(chat_id, message_id, "لغو شد.")
            elif step == "k":
                kind = parts[1]
                rows = [[(month_label(y, m), f"fg:m:{kind}:{y}:{m}") for y, m in recent_months(today)]]
                self._edit(chat_id, message_id, f"ثبت {KIND_LABEL[kind]} فراموش‌شده\nماه را انتخاب کنید:",
                           inline_keyboard(rows + [CANCEL_ROW]))
            elif step == "m":
                kind, y, m = parts[1], int(parts[2]), int(parts[3])
                self._edit(chat_id, message_id, f"ثبت {KIND_LABEL[kind]} — {month_label(y, m)}\nروز را انتخاب کنید:",
                           inline_keyboard(self._day_rows(kind, y, m, today) + [CANCEL_ROW]))
            elif step == "d":
                kind, y, m, d = parts[1], int(parts[2]), int(parts[3]), int(parts[4])
                day = to_gregorian(y, m, d)
                hours = [(f"{h:02d}", f"fg:h:{kind}:{y}:{m}:{d}:{h}") for h in range(24)]
                rows = [hours[i:i + 6] for i in range(0, 24, 6)]
                self._edit(chat_id, message_id, f"ثبت {KIND_LABEL[kind]} — {format_date(day)}\nساعت را انتخاب کنید:",
                           inline_keyboard(rows + [CANCEL_ROW]))
            elif step == "h":
                kind, y, m, d, h = parts[1], *map(int, parts[2:6])
                day = to_gregorian(y, m, d)
                self.db.set_state(chat_id, "await_minute", {"kind": kind, "date": day.isoformat(), "hour": h})
                self._edit(chat_id, message_id,
                           f"ثبت {KIND_LABEL[kind]} — {format_date(day)} ساعت {h:02d}\n"
                           "دقیقه را تایپ کنید (عددی بین 0 تا 59):")
            elif step in ("ok", "no"):
                self._confirm(chat_id, message_id, step == "ok")
        except (IndexError, ValueError, KeyError) as exc:
            log.warning("bad forgot callback %r: %s", parts, exc)
            self._edit(chat_id, message_id, "این دکمه منقضی شده است. دوباره از منو شروع کنید.")

    @staticmethod
    def _day_rows(kind: str, y: int, m: int, today: date) -> list:
        last = days_in_month(y, m)
        j = to_jalali(today)
        if (y, m) == (j.year, j.month):
            last = j.day
        buttons = [(str(d), f"fg:d:{kind}:{y}:{m}:{d}") for d in range(1, last + 1)]
        return [buttons[i:i + 7] for i in range(0, len(buttons), 7)]

    def _minute_entered(self, chat_id, text: str, data: dict) -> None:
        if not text.isdigit() or not 0 <= int(text) <= 59:
            self.send(chat_id, "لطفاً فقط یک عدد بین 0 تا 59 بنویسید (یا /cancel):")
            return
        at = datetime.fromisoformat(data["date"]).replace(hour=data["hour"], minute=int(text))
        data = {**data, "at": at.isoformat()}
        self.db.set_state(chat_id, "await_confirm", data)
        self.send(
            chat_id,
            f"ثبت {KIND_LABEL[data['kind']]} برای {format_date(at.date())} ساعت {format_time(at)}؟",
            inline_keyboard([[("✔️ تأیید", "fg:ok"), ("✖️ لغو", "fg:no")]]),
        )

    def _confirm(self, chat_id, message_id, accepted: bool) -> None:
        state, data = self.db.get_state(chat_id)
        self.db.clear_state(chat_id)
        if not accepted:
            self._edit(chat_id, message_id, "لغو شد.")
            return
        if state != "await_confirm":
            self._edit(chat_id, message_id, "این درخواست منقضی شده است. دوباره از منو شروع کنید.")
            return
        at = datetime.fromisoformat(data["at"])
        now = self.now()
        try:
            if data["kind"] == "in":
                session = self.attendance.add_forgotten_check_in(chat_id, at, now)
            else:
                session = self.attendance.add_forgotten_check_out(chat_id, at, now)
        except AttendanceError as err:
            self._edit(chat_id, message_id, err.message, stale_button(err.stale) if err.stale else None)
            return
        label = KIND_LABEL[data["kind"]]
        self._edit(chat_id, message_id, f"✅ {label} ثبت شد: {format_date(at.date())} ساعت {format_time(at)}")
        # A past check-in with no check-out yet: offer to record that too.
        if data["kind"] == "in" and session.check_out is None and at.date() < now.date():
            self.send(chat_id, "خروجِ همان روز را هم ثبت کنید:", stale_button(session))

    # --- reports -----------------------------------------------------------

    def _report_menu(self, chat_id) -> None:
        rows = [
            [("هفته‌ی جاری", "rp:me:w"), ("ماه جاری", "rp:me:m"), ("ماه قبل", "rp:me:pm")],
            [("📥 اکسل ماه جاری", "rp:mex:m"), ("📥 اکسل ماه قبل", "rp:mex:pm")],
        ]
        if self.is_admin(chat_id):
            rows += [
                [("👥 همه: هفته", "rp:all:w"), ("👥 همه: ماه", "rp:all:m"), ("👥 همه: ماه قبل", "rp:all:pm")],
                [("📥 اکسل همه: ماه جاری", "rp:allx:m"), ("📥 اکسل همه: ماه قبل", "rp:allx:pm")],
            ]
        self.send(chat_id, "کدام گزارش؟", inline_keyboard(rows))

    def period(self, code: str) -> tuple[date, date, str]:
        today = self.now().date()
        if code == "w":
            return week_start(today), today, "گزارش هفته‌ی جاری"
        if code == "m":
            first, _ = month_range(today)
            return first, today, "گزارش ماه جاری"
        if code == "pm":
            first, _ = month_range(today)
            start, end = month_range(first - timedelta(days=1))
            j = to_jalali(start)
            return start, end, f"گزارش {MONTHS[j.month - 1]} {j.year}"
        raise ValueError(code)

    def _report_callback(self, chat_id, parts: list[str]) -> None:
        try:
            scope, code = parts[0], parts[1]
            start, end, title = self.period(code)
        except (IndexError, ValueError):
            return
        user = self.db.get_user(chat_id)
        if scope in ("all", "allx") and not self.is_admin(chat_id):
            self.send(chat_id, "این گزارش فقط برای مدیران است.")
            return
        if scope == "me":
            sessions = self.db.sessions_between(start, end, chat_id)
            self.send(chat_id, user_report(user, sessions, start, end, title))
        elif scope == "mex":
            sessions = self.db.sessions_between(start, end, chat_id)
            content = build_workbook([user], sessions, start, end)
            self.client.send_document(chat_id, file_name(start, end, "me"), content, caption=title)
        elif scope == "all":
            self.send(chat_id, team_report(self.db.list_users(), self.db.sessions_between(start, end), start, end, title))
        elif scope == "allx":
            content = build_workbook(self.db.list_users(), self.db.sessions_between(start, end), start, end)
            self.client.send_document(chat_id, file_name(start, end), content, caption=title)
