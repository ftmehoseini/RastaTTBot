"""Thin client for the Soroush Plus Bot API.

The API follows the Telegram Bot API shape: POST {base}{token}/{method},
JSON body, response {"ok": bool, "result": ..., "description": ...}.
"""

import json
from typing import Any, Optional

import requests


class SoroushAPIError(Exception):
    """The API answered, but with ok=false or a non-JSON body."""


class SoroushClient:
    def __init__(
        self,
        token: str,
        api_base: str = "https://api.splus.ir/bot",
        session: Optional[requests.Session] = None,
        timeout: float = 30,
    ):
        self._url = f"{api_base.rstrip('/')}{token}"
        self._session = session or requests.Session()
        self._timeout = timeout

    def call(
        self,
        method: str,
        http_timeout: Optional[float] = None,
        files: Optional[dict] = None,
        **params: Any,
    ) -> Any:
        payload = {k: v for k, v in params.items() if v is not None}
        url = f"{self._url}/{method}"
        timeout = http_timeout or self._timeout
        if files:
            # Multipart upload: non-file fields go as form data, objects JSON-encoded.
            form = {k: json.dumps(v) if isinstance(v, (dict, list)) else str(v) for k, v in payload.items()}
            response = self._session.post(url, data=form, files=files, timeout=timeout)
        else:
            response = self._session.post(url, json=payload, timeout=timeout)
        try:
            data = response.json()
        except ValueError as exc:
            raise SoroushAPIError(
                f"{method}: HTTP {response.status_code}, non-JSON response: {response.text[:200]}"
            ) from exc
        if not data.get("ok"):
            code = data.get("error_code", response.status_code)
            raise SoroushAPIError(f"{method}: {code} {data.get('description', '')}".strip())
        return data.get("result")

    def get_me(self) -> dict:
        return self.call("getMe")

    def get_updates(self, offset: Optional[int] = None, timeout: int = 25) -> list:
        # Long polling: the HTTP timeout must outlive the server-side wait.
        return self.call("getUpdates", http_timeout=timeout + 10, offset=offset, timeout=timeout) or []

    def send_message(
        self, chat_id: Any, text: str, reply_markup: Optional[dict] = None
    ) -> dict:
        return self.call("sendMessage", chat_id=chat_id, text=text, reply_markup=reply_markup)

    def edit_message_text(
        self, chat_id: Any, message_id: int, text: str, reply_markup: Optional[dict] = None
    ) -> Any:
        return self.call(
            "editMessageText",
            chat_id=chat_id,
            message_id=message_id,
            text=text,
            reply_markup=reply_markup,
        )

    def send_document(
        self, chat_id: Any, filename: str, content: bytes, caption: Optional[str] = None
    ) -> dict:
        return self.call(
            "sendDocument",
            http_timeout=120,
            files={"document": (filename, content)},
            chat_id=chat_id,
            caption=caption,
        )

    def answer_callback_query(self, callback_query_id: str, text: Optional[str] = None) -> Any:
        return self.call("answerCallbackQuery", callback_query_id=callback_query_id, text=text)


def inline_keyboard(rows: list[list[tuple[str, str]]]) -> dict:
    """Build an inline keyboard from rows of (label, callback_data)."""
    return {
        "inline_keyboard": [
            [{"text": label, "callback_data": data} for label, data in row] for row in rows
        ]
    }


def reply_keyboard(rows: list[list[str]]) -> dict:
    """A persistent keyboard under the input box; pressing a button sends its text."""
    return {
        "keyboard": [[{"text": label} for label in row] for row in rows],
        "resize_keyboard": True,
    }
