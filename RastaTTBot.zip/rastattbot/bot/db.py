"""SQLite storage: users, attendance sessions, per-user conversation state, job runs.

Times are stored as naive ISO strings in the office timezone ("2026-10-12T08:30:00").
Each method opens its own connection, so the polling loop and the scheduler
thread can share one Database object safely.
"""

import json
import os
import sqlite3
from contextlib import contextmanager
from dataclasses import dataclass
from datetime import date, datetime, timedelta
from typing import Optional

SCHEMA = """
CREATE TABLE IF NOT EXISTS users (
    chat_id     TEXT PRIMARY KEY,
    full_name   TEXT NOT NULL,
    created_at  TEXT NOT NULL,
    active      INTEGER NOT NULL DEFAULT 1
);

CREATE TABLE IF NOT EXISTS sessions (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    chat_id     TEXT NOT NULL REFERENCES users(chat_id),
    check_in    TEXT NOT NULL,
    check_out   TEXT,
    manual_in   INTEGER NOT NULL DEFAULT 0,
    manual_out  INTEGER NOT NULL DEFAULT 0
);
CREATE INDEX IF NOT EXISTS idx_sessions_user_in ON sessions(chat_id, check_in);

CREATE TABLE IF NOT EXISTS user_state (
    chat_id     TEXT PRIMARY KEY,
    state       TEXT NOT NULL,
    data        TEXT NOT NULL DEFAULT '{}'
);

CREATE TABLE IF NOT EXISTS job_runs (
    job         TEXT NOT NULL,
    run_date    TEXT NOT NULL,
    PRIMARY KEY (job, run_date)
);
"""


@dataclass(frozen=True)
class User:
    chat_id: str
    full_name: str


@dataclass(frozen=True)
class Session:
    id: int
    chat_id: str
    check_in: datetime
    check_out: Optional[datetime]
    manual_in: bool
    manual_out: bool

    @property
    def duration(self) -> Optional[timedelta]:
        return self.check_out - self.check_in if self.check_out else None


def _ts(dt: datetime) -> str:
    return dt.replace(microsecond=0).isoformat()


def _row_to_session(row) -> Session:
    return Session(
        id=row["id"],
        chat_id=row["chat_id"],
        check_in=datetime.fromisoformat(row["check_in"]),
        check_out=datetime.fromisoformat(row["check_out"]) if row["check_out"] else None,
        manual_in=bool(row["manual_in"]),
        manual_out=bool(row["manual_out"]),
    )


class Database:
    def __init__(self, path: str):
        self.path = path
        if path != ":memory:":
            os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
        else:
            # A shared in-memory DB needs one persistent connection (used by tests).
            self._memory_conn = sqlite3.connect(":memory:", check_same_thread=False)
            self._memory_conn.row_factory = sqlite3.Row
        with self._conn() as conn:
            conn.executescript(SCHEMA)
            if path != ":memory:":
                conn.execute("PRAGMA journal_mode=WAL")

    @contextmanager
    def _conn(self):
        if self.path == ":memory:":
            conn = self._memory_conn
            with conn:
                yield conn
            return
        conn = sqlite3.connect(self.path, timeout=30)
        conn.row_factory = sqlite3.Row
        try:
            with conn:
                yield conn
        finally:
            conn.close()

    # --- users -------------------------------------------------------------

    def get_user(self, chat_id) -> Optional[User]:
        with self._conn() as conn:
            row = conn.execute(
                "SELECT chat_id, full_name FROM users WHERE chat_id = ? AND active = 1",
                (str(chat_id),),
            ).fetchone()
        return User(row["chat_id"], row["full_name"]) if row else None

    def upsert_user(self, chat_id, full_name: str, now: datetime) -> None:
        with self._conn() as conn:
            conn.execute(
                """INSERT INTO users (chat_id, full_name, created_at) VALUES (?, ?, ?)
                   ON CONFLICT(chat_id) DO UPDATE SET full_name = excluded.full_name, active = 1""",
                (str(chat_id), full_name, _ts(now)),
            )

    def list_users(self) -> list[User]:
        with self._conn() as conn:
            rows = conn.execute(
                "SELECT chat_id, full_name FROM users WHERE active = 1 ORDER BY full_name"
            ).fetchall()
        return [User(r["chat_id"], r["full_name"]) for r in rows]

    # --- sessions ----------------------------------------------------------

    def open_session(self, chat_id) -> Optional[Session]:
        with self._conn() as conn:
            row = conn.execute(
                """SELECT * FROM sessions WHERE chat_id = ? AND check_out IS NULL
                   ORDER BY check_in DESC LIMIT 1""",
                (str(chat_id),),
            ).fetchone()
        return _row_to_session(row) if row else None

    def add_check_in(self, chat_id, at: datetime, manual: bool = False) -> int:
        with self._conn() as conn:
            cur = conn.execute(
                "INSERT INTO sessions (chat_id, check_in, manual_in) VALUES (?, ?, ?)",
                (str(chat_id), _ts(at), int(manual)),
            )
            return cur.lastrowid

    def update_check_in(self, session_id: int, at: datetime, manual: bool = False) -> None:
        with self._conn() as conn:
            conn.execute(
                "UPDATE sessions SET check_in = ?, manual_in = ? WHERE id = ?",
                (_ts(at), int(manual), session_id),
            )

    def set_check_out(self, session_id: int, at: datetime, manual: bool = False) -> None:
        with self._conn() as conn:
            conn.execute(
                "UPDATE sessions SET check_out = ?, manual_out = ? WHERE id = ?",
                (_ts(at), int(manual), session_id),
            )

    def sessions_between(self, start: date, end: date, chat_id=None) -> list[Session]:
        """Sessions whose check-in falls on a date in [start, end]."""
        params = [start.isoformat(), (end + timedelta(days=1)).isoformat()]
        sql = "SELECT * FROM sessions WHERE check_in >= ? AND check_in < ?"
        if chat_id is not None:
            sql += " AND chat_id = ?"
            params.append(str(chat_id))
        sql += " ORDER BY check_in"
        with self._conn() as conn:
            rows = conn.execute(sql, params).fetchall()
        return [_row_to_session(r) for r in rows]

    def overlapping_session(self, chat_id, at: datetime) -> Optional[Session]:
        """A closed session that contains `at`, if any."""
        with self._conn() as conn:
            row = conn.execute(
                """SELECT * FROM sessions WHERE chat_id = ? AND check_out IS NOT NULL
                   AND check_in <= ? AND check_out > ? LIMIT 1""",
                (str(chat_id), _ts(at), _ts(at)),
            ).fetchone()
        return _row_to_session(row) if row else None

    def next_session_after(self, chat_id, at: datetime) -> Optional[Session]:
        with self._conn() as conn:
            row = conn.execute(
                """SELECT * FROM sessions WHERE chat_id = ? AND check_in > ?
                   ORDER BY check_in LIMIT 1""",
                (str(chat_id), _ts(at)),
            ).fetchone()
        return _row_to_session(row) if row else None

    def stale_open_sessions(self, before: date) -> list[Session]:
        """Open sessions that started before the given date (forgotten check-outs)."""
        with self._conn() as conn:
            rows = conn.execute(
                "SELECT * FROM sessions WHERE check_out IS NULL AND check_in < ? ORDER BY check_in",
                (before.isoformat(),),
            ).fetchall()
        return [_row_to_session(r) for r in rows]

    # --- conversation state ------------------------------------------------

    def get_state(self, chat_id) -> tuple[Optional[str], dict]:
        with self._conn() as conn:
            row = conn.execute(
                "SELECT state, data FROM user_state WHERE chat_id = ?", (str(chat_id),)
            ).fetchone()
        if not row:
            return None, {}
        return row["state"], json.loads(row["data"])

    def set_state(self, chat_id, state: str, data: Optional[dict] = None) -> None:
        with self._conn() as conn:
            conn.execute(
                """INSERT INTO user_state (chat_id, state, data) VALUES (?, ?, ?)
                   ON CONFLICT(chat_id) DO UPDATE SET state = excluded.state, data = excluded.data""",
                (str(chat_id), state, json.dumps(data or {}, ensure_ascii=False)),
            )

    def clear_state(self, chat_id) -> None:
        with self._conn() as conn:
            conn.execute("DELETE FROM user_state WHERE chat_id = ?", (str(chat_id),))

    # --- scheduled jobs ----------------------------------------------------

    def claim_job_run(self, job: str, run_date: date) -> bool:
        """Record that a job ran on a date. False if it already ran that day."""
        with self._conn() as conn:
            cur = conn.execute(
                "INSERT OR IGNORE INTO job_runs (job, run_date) VALUES (?, ?)",
                (job, run_date.isoformat()),
            )
            return cur.rowcount == 1

    def backup(self, dest_path: str) -> None:
        with self._conn() as conn:
            dest = sqlite3.connect(dest_path)
            try:
                conn.backup(dest)
            finally:
                dest.close()
