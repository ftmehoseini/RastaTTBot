"""Daily reminder and weekly report, run from a background thread.

Each job runs at most once per day (recorded in the job_runs table), so a
restart never double-sends. If the bot was down at the scheduled time, the
job still runs when it comes back, as long as it is within the grace window.
"""

import logging
import threading
from dataclasses import dataclass
from datetime import datetime, time, timedelta
from typing import Callable

from .config import Config
from .db import Database
from .excel_export import build_workbook, file_name
from .handlers import stale_button
from .jalali import format_date, format_time, week_start
from .reports import team_report, user_report
from .soroush_api import SoroushAPIError, SoroushClient

log = logging.getLogger(__name__)

GRACE = timedelta(hours=3)


@dataclass(frozen=True)
class Job:
    name: str
    days: tuple
    at: time
    run: Callable[[datetime], None]

    def is_due(self, now: datetime) -> bool:
        if now.weekday() not in self.days:
            return False
        scheduled = datetime.combine(now.date(), self.at)
        return scheduled <= now < scheduled + GRACE


class Scheduler:
    def __init__(self, client: SoroushClient, db: Database, config: Config, now: Callable[[], datetime]):
        self.client = client
        self.db = db
        self.config = config
        self.now = now
        self.jobs = [
            Job("checkout_reminder", config.workdays, config.reminder_time, self.send_reminders),
            Job("weekly_report", (config.weekly_report_day,), config.weekly_report_time, self.send_weekly_reports),
        ]
        self._stop = threading.Event()

    def tick(self) -> None:
        now = self.now()
        for job in self.jobs:
            if job.is_due(now) and self.db.claim_job_run(job.name, now.date()):
                log.info("running job %s", job.name)
                try:
                    job.run(now)
                except Exception:
                    log.exception("job %s failed", job.name)

    def run_forever(self, interval: float = 30) -> None:
        while not self._stop.is_set():
            try:
                self.tick()
            except Exception:
                log.exception("scheduler tick failed")
            self._stop.wait(interval)

    def start(self) -> threading.Thread:
        thread = threading.Thread(target=self.run_forever, name="scheduler", daemon=True)
        thread.start()
        return thread

    def stop(self) -> None:
        self._stop.set()

    def _safe_send(self, chat_id, text: str, markup=None) -> None:
        try:
            self.client.send_message(chat_id, text, reply_markup=markup)
        except (SoroushAPIError, OSError) as exc:
            log.warning("could not message %s: %s", chat_id, exc)

    # --- jobs --------------------------------------------------------------

    def send_reminders(self, now: datetime) -> None:
        """Remind everyone with a check-in from an earlier day that has no check-out."""
        for session in self.db.stale_open_sessions(before=now.date()):
            self._safe_send(
                session.chat_id,
                "⏰ یادآوری: خروجِ شما برای "
                f"{format_date(session.check_in.date())} (ورود ساعت {format_time(session.check_in)}) ثبت نشده است.",
                stale_button(session),
            )

    def send_weekly_reports(self, now: datetime) -> None:
        start, end = week_start(now.date()), now.date()
        title = "گزارش هفتگی"
        users = self.db.list_users()
        sessions = self.db.sessions_between(start, end)
        for user in users:
            mine = [s for s in sessions if s.chat_id == user.chat_id]
            self._safe_send(user.chat_id, user_report(user, mine, start, end, title))
        if not self.config.admin_ids:
            return
        report = team_report(users, sessions, start, end, title)
        content = build_workbook(users, sessions, start, end)
        for admin in self.config.admin_ids:
            self._safe_send(admin, report)
            try:
                self.client.send_document(admin, file_name(start, end), content, caption=title)
            except (SoroushAPIError, OSError) as exc:
                log.warning("could not send weekly Excel to %s: %s", admin, exc)
