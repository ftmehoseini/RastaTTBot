"""Build .xlsx attendance files from the database (the database is the source of truth)."""

import io
from collections import defaultdict
from datetime import date

from openpyxl import Workbook
from openpyxl.styles import Alignment, Font, PatternFill

from .db import Session, User
from .jalali import WEEKDAYS, format_date_short, format_duration, format_time
from .reports import summarize

HEADER_FILL = PatternFill("solid", fgColor="DDEBF7")
WARN_FILL = PatternFill("solid", fgColor="FCE4D6")


def _style_header(ws, widths: list[int]) -> None:
    ws.sheet_view.rightToLeft = True
    for col, width in enumerate(widths, start=1):
        cell = ws.cell(row=1, column=col)
        cell.font = Font(bold=True)
        cell.fill = HEADER_FILL
        cell.alignment = Alignment(horizontal="center")
        ws.column_dimensions[cell.column_letter].width = width
    ws.freeze_panes = "A2"


def build_workbook(users: list[User], sessions: list[Session], start: date, end: date) -> bytes:
    names = {u.chat_id: u.full_name for u in users}
    wb = Workbook()

    detail = wb.active
    detail.title = "جزئیات"
    detail.append(["نام", "تاریخ", "روز", "ورود", "خروج", "مدت (ساعت:دقیقه)", "ثبت دستی"])
    _style_header(detail, [22, 13, 11, 9, 9, 17, 10])
    for s in sessions:
        manual = "بله" if (s.manual_in or s.manual_out) else ""
        detail.append([
            names.get(s.chat_id, s.chat_id),
            format_date_short(s.check_in.date()),
            WEEKDAYS[s.check_in.weekday()],
            format_time(s.check_in),
            format_time(s.check_out) if s.check_out else "ثبت نشده",
            format_duration(s.duration) if s.duration else "",
            manual,
        ])
        if s.check_out is None:
            for cell in detail[detail.max_row]:
                cell.fill = WARN_FILL

    by_user = defaultdict(list)
    for s in sessions:
        by_user[s.chat_id].append(s)
    summary_ws = wb.create_sheet("خلاصه")
    summary_ws.append(["نام", "روزهای حضور", "مجموع ساعت", "خروج ثبت‌نشده"])
    _style_header(summary_ws, [22, 14, 14, 15])
    for user in users:
        summary = summarize(by_user.get(user.chat_id, []))
        summary_ws.append([
            user.full_name,
            len(summary.days),
            format_duration(summary.total),
            len(summary.open_sessions),
        ])
    summary_ws.append([])
    summary_ws.append([f"بازه: {format_date_short(start)} تا {format_date_short(end)}"])

    buffer = io.BytesIO()
    wb.save(buffer)
    return buffer.getvalue()


def file_name(start: date, end: date, who: str = "team") -> str:
    return f"attendance_{who}_{format_date_short(start).replace('/', '-')}_{format_date_short(end).replace('/', '-')}.xlsx"
