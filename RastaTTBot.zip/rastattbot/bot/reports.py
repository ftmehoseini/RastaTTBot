"""Text reports for one person or the whole team."""

from collections import defaultdict
from dataclasses import dataclass, field
from datetime import date, timedelta

from .db import Session, User
from .jalali import format_date, format_date_short, format_duration, format_time


@dataclass
class Summary:
    total: timedelta = field(default_factory=timedelta)
    days: set = field(default_factory=set)
    open_sessions: list = field(default_factory=list)
    by_day: dict = field(default_factory=lambda: defaultdict(list))


def summarize(sessions: list[Session]) -> Summary:
    summary = Summary()
    for s in sessions:
        day = s.check_in.date()
        summary.days.add(day)
        summary.by_day[day].append(s)
        if s.duration is not None:
            summary.total += s.duration
        else:
            summary.open_sessions.append(s)
    return summary


def _session_line(s: Session) -> str:
    out = format_time(s.check_out) if s.check_out else "—"
    if s.check_out and s.check_out.date() != s.check_in.date():
        out += " (روز بعد)"
    marks = " ✍️" if (s.manual_in or s.manual_out) else ""
    duration = format_duration(s.duration) if s.duration else "خروج ثبت نشده ⚠️"
    return f"  ورود {format_time(s.check_in)} | خروج {out} | {duration}{marks}"


def user_report(user: User, sessions: list[Session], start: date, end: date, title: str) -> str:
    summary = summarize(sessions)
    lines = [
        f"📊 {title}",
        f"👤 {user.full_name}",
        f"🗓 {format_date_short(start)} تا {format_date_short(end)}",
        "",
    ]
    if not sessions:
        lines.append("در این بازه حضوری ثبت نشده است.")
        return "\n".join(lines)
    for day in sorted(summary.by_day):
        lines.append(f"• {format_date(day)}")
        lines.extend(_session_line(s) for s in summary.by_day[day])
    lines += [
        "",
        f"روزهای حضور: {len(summary.days)}",
        f"مجموع ساعت کار: {format_duration(summary.total)}",
    ]
    if summary.open_sessions:
        lines.append(f"⚠️ خروج‌های ثبت‌نشده: {len(summary.open_sessions)}")
    if any(s.manual_in or s.manual_out for s in sessions):
        lines.append("✍️ = ثبت دستی (فراموش‌شده)")
    return "\n".join(lines)


def team_report(users: list[User], sessions: list[Session], start: date, end: date, title: str) -> str:
    by_user = defaultdict(list)
    for s in sessions:
        by_user[s.chat_id].append(s)
    lines = [
        f"📊 {title} — همه‌ی کارکنان",
        f"🗓 {format_date_short(start)} تا {format_date_short(end)}",
        "",
    ]
    for user in users:
        summary = summarize(by_user.get(user.chat_id, []))
        line = (
            f"👤 {user.full_name}: {len(summary.days)} روز، "
            f"{format_duration(summary.total)} ساعت"
        )
        if summary.open_sessions:
            line += f" (⚠️ {len(summary.open_sessions)} خروج ثبت‌نشده)"
        lines.append(line)
    if not users:
        lines.append("هنوز کسی در ربات ثبت‌نام نکرده است.")
    return "\n".join(lines)
