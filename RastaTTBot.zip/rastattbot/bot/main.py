"""Run the attendance bot: long-polls Soroush for updates and runs the scheduler.

    python -m bot.main
"""

import logging
import time
from datetime import datetime
from zoneinfo import ZoneInfo

import requests

from .config import load_config
from .db import Database
from .handlers import BotHandlers
from .scheduler import Scheduler
from .soroush_api import SoroushAPIError, SoroushClient

log = logging.getLogger("bot")


def main() -> None:
    logging.basicConfig(
        level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s: %(message)s"
    )
    config = load_config()
    tz = ZoneInfo(config.timezone)

    def now() -> datetime:
        return datetime.now(tz).replace(tzinfo=None, microsecond=0)

    db = Database(config.db_path)
    client = SoroushClient(config.token, config.api_base)
    handlers = BotHandlers(client, db, config, now)

    # The scheduler thread gets its own HTTP client.
    scheduler = Scheduler(SoroushClient(config.token, config.api_base), db, config, now)
    scheduler.start()

    me = client.get_me()
    log.info("bot started as @%s; admins=%s", me.get("username"), sorted(config.admin_ids))

    offset = None
    backoff = 1
    while True:
        try:
            updates = client.get_updates(offset=offset, timeout=25)
            backoff = 1
        except (SoroushAPIError, requests.RequestException) as exc:
            log.warning("getUpdates failed: %s (retrying in %ss)", exc, backoff)
            time.sleep(backoff)
            backoff = min(backoff * 2, 60)
            continue
        for update in updates:
            offset = update["update_id"] + 1
            try:
                handlers.handle_update(update)
            except Exception:
                log.exception("failed to handle update %s", update.get("update_id"))


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        pass
