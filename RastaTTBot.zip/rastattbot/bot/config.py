"""Settings loaded from environment variables (or a local .env file)."""

import os
from dataclasses import dataclass, field
from datetime import time

from dotenv import load_dotenv

DEFAULT_API_BASE = "https://api.splus.ir/bot"

# Python weekday numbers (Monday = 0). Saturday–Thursday.
DEFAULT_WORKDAYS = (5, 6, 0, 1, 2, 3)

_WEEKDAY_NAMES = {
    "mon": 0, "tue": 1, "wed": 2, "thu": 3, "fri": 4, "sat": 5, "sun": 6,
}


@dataclass(frozen=True)
class Config:
    token: str
    api_base: str = DEFAULT_API_BASE
    timezone: str = "Asia/Tehran"
    db_path: str = "data/attendance.sqlite3"
    admin_ids: frozenset = field(default_factory=frozenset)
    workdays: tuple = DEFAULT_WORKDAYS
    reminder_time: time = time(10, 0)
    weekly_report_day: int = 3  # Thursday
    weekly_report_time: time = time(14, 0)
    max_shift_hours: int = 16


def _parse_time(value: str, name: str) -> time:
    try:
        hour, minute = value.strip().split(":")
        return time(int(hour), int(minute))
    except ValueError:
        raise SystemExit(f"{name} must look like HH:MM, got {value!r}")


def _parse_weekday(value: str, name: str) -> int:
    key = value.strip().lower()[:3]
    if key not in _WEEKDAY_NAMES:
        raise SystemExit(f"{name} must be a weekday name like 'thu', got {value!r}")
    return _WEEKDAY_NAMES[key]


def _parse_ids(value: str) -> frozenset:
    return frozenset(part for part in value.replace(" ", "").split(",") if part)


def load_config() -> Config:
    load_dotenv()
    env = os.environ
    token = env.get("SOROUSH_BOT_TOKEN", "").strip()
    if not token:
        raise SystemExit(
            "SOROUSH_BOT_TOKEN is not set. Copy .env.example to .env and add your bot token."
        )
    workdays = DEFAULT_WORKDAYS
    if env.get("WORKDAYS"):
        workdays = tuple(_parse_weekday(d, "WORKDAYS") for d in env["WORKDAYS"].split(","))
    return Config(
        token=token,
        api_base=env.get("SOROUSH_API_BASE", DEFAULT_API_BASE).rstrip("/"),
        timezone=env.get("TIMEZONE", "Asia/Tehran"),
        db_path=env.get("DB_PATH", "data/attendance.sqlite3"),
        admin_ids=_parse_ids(env.get("ADMIN_IDS", "")),
        workdays=workdays,
        reminder_time=_parse_time(env.get("REMINDER_TIME", "10:00"), "REMINDER_TIME"),
        weekly_report_day=_parse_weekday(env.get("WEEKLY_REPORT_DAY", "thu"), "WEEKLY_REPORT_DAY"),
        weekly_report_time=_parse_time(env.get("WEEKLY_REPORT_TIME", "14:00"), "WEEKLY_REPORT_TIME"),
        max_shift_hours=int(env.get("MAX_SHIFT_HOURS", "16")),
    )
