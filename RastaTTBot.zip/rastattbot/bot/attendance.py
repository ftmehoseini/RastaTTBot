"""Check-in / check-out rules. Messages are in Persian because they go straight to users."""

from datetime import datetime, timedelta
from typing import Optional

from .db import Database, Session
from .jalali import format_date, format_time


class AttendanceError(Exception):
    """A rule was broken. `stale` is set when an earlier check-out is missing."""

    def __init__(self, message: str, stale: Optional[Session] = None):
        super().__init__(message)
        self.message = message
        self.stale = stale


def _when(dt: datetime) -> str:
    return f"{format_date(dt.date())} ساعت {format_time(dt)}"


class Attendance:
    def __init__(self, db: Database, max_shift_hours: int = 16):
        self.db = db
        self.max_shift = timedelta(hours=max_shift_hours)

    def _stale_error(self, session: Session) -> AttendanceError:
        return AttendanceError(
            f"⚠️ خروجِ ورودِ {_when(session.check_in)} ثبت نشده است.\n"
            "لطفاً اول ساعت خروج آن روز را با «📝 ثبت ساعت فراموش‌شده» وارد کنید.",
            stale=session,
        )

    def _current_open(self, chat_id, now: datetime) -> Optional[Session]:
        """The open session, or raise if it is too old to still be the current shift."""
        session = self.db.open_session(chat_id)
        if session and now - session.check_in > self.max_shift:
            raise self._stale_error(session)
        return session

    # --- live buttons ------------------------------------------------------

    def check_in(self, chat_id, now: datetime) -> Session:
        session = self._current_open(chat_id, now)
        if session:
            raise AttendanceError(f"شما قبلاً در {_when(session.check_in)} ورود زده‌اید.")
        session_id = self.db.add_check_in(chat_id, now)
        return Session(session_id, str(chat_id), now.replace(microsecond=0), None, False, False)

    def check_out(self, chat_id, now: datetime) -> Session:
        session = self._current_open(chat_id, now)
        if not session:
            raise AttendanceError(
                "ورودی برای امروز ثبت نشده است.\n"
                "اگر ورود را فراموش کرده‌اید، از «📝 ثبت ساعت فراموش‌شده» استفاده کنید."
            )
        now = now.replace(microsecond=0)
        self.db.set_check_out(session.id, now)
        return Session(session.id, session.chat_id, session.check_in, now, session.manual_in, False)

    # --- forgotten entries -------------------------------------------------

    def add_forgotten_check_in(self, chat_id, at: datetime, now: datetime) -> Session:
        if at > now:
            raise AttendanceError("زمان واردشده در آینده است.")
        if self.db.overlapping_session(chat_id, at):
            raise AttendanceError("این زمان با یک حضورِ ثبت‌شده‌ی دیگر هم‌پوشانی دارد.")

        session = self.db.open_session(chat_id)
        if session:
            # Same day, earlier than the button press: the person arrived before they checked in.
            if at < session.check_in and at.date() == session.check_in.date():
                following = self.db.next_session_after(chat_id, at)
                if following and following.id != session.id:
                    raise AttendanceError("این زمان با یک حضورِ ثبت‌شده‌ی دیگر هم‌پوشانی دارد.")
                self.db.update_check_in(session.id, at, manual=True)
                return Session(session.id, session.chat_id, at, None, True, False)
            if now - session.check_in > self.max_shift:
                raise self._stale_error(session)
            raise AttendanceError(
                f"شما در {_when(session.check_in)} ورود زده‌اید و هنوز خروج نزده‌اید."
            )

        session_id = self.db.add_check_in(chat_id, at, manual=True)
        return Session(session_id, str(chat_id), at, None, True, False)

    def add_forgotten_check_out(self, chat_id, at: datetime, now: datetime) -> Session:
        if at > now:
            raise AttendanceError("زمان واردشده در آینده است.")
        session = self.db.open_session(chat_id)
        if not session:
            raise AttendanceError(
                "ورودِ بازی برای ثبت خروج وجود ندارد. اول ساعت ورود را ثبت کنید."
            )
        if at <= session.check_in:
            raise AttendanceError(f"ساعت خروج باید بعد از ورودِ {_when(session.check_in)} باشد.")
        if at - session.check_in > self.max_shift:
            raise AttendanceError(
                f"مدت حضور بیش از {int(self.max_shift.total_seconds() // 3600)} ساعت می‌شود. "
                f"ورود شما {_when(session.check_in)} است؛ لطفاً زمان را بررسی کنید."
            )
        following = self.db.next_session_after(chat_id, session.check_in)
        if following and at > following.check_in:
            raise AttendanceError(
                f"ساعت خروج باید قبل از ورود بعدی شما ({_when(following.check_in)}) باشد."
            )
        self.db.set_check_out(session.id, at, manual=True)
        return Session(session.id, session.chat_id, session.check_in, at, session.manual_in, True)
