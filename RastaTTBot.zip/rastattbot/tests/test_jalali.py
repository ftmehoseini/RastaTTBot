from datetime import date, timedelta

from bot import jalali


def test_conversion_round_trip():
    j = jalali.to_jalali(date(2026, 10, 12))
    assert (j.year, j.month, j.day) == (1405, 7, 20)
    assert jalali.to_gregorian(1405, 7, 20) == date(2026, 10, 12)


def test_days_in_month():
    assert jalali.days_in_month(1405, 1) == 31
    assert jalali.days_in_month(1405, 7) == 30
    assert jalali.days_in_month(1403, 12) == 30  # leap year
    assert jalali.days_in_month(1405, 12) == 29


def test_recent_months_wraps_year():
    farvardin_day = jalali.to_gregorian(1405, 2, 5)
    assert jalali.recent_months(farvardin_day) == [(1405, 2), (1405, 1), (1404, 12)]


def test_week_starts_on_saturday():
    monday = date(2026, 10, 12)
    assert jalali.week_start(monday) == date(2026, 10, 10)
    assert jalali.week_start(date(2026, 10, 10)) == date(2026, 10, 10)
    assert jalali.week_start(date(2026, 10, 16)) == date(2026, 10, 10)  # Friday


def test_month_range():
    first, last = jalali.month_range(date(2026, 10, 12))
    assert first == jalali.to_gregorian(1405, 7, 1)
    assert last == jalali.to_gregorian(1405, 7, 30)


def test_formatting():
    assert jalali.format_date(date(2026, 10, 12)) == "دوشنبه 20 مهر 1405"
    assert jalali.format_duration(timedelta(hours=8, minutes=5)) == "8:05"
    assert jalali.normalize_digits("۴۵") == "45"
    assert jalali.normalize_digits("٣٠") == "30"
