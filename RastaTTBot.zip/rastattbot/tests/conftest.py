from datetime import datetime

import pytest

from bot.config import Config
from bot.db import Database


class Clock:
    def __init__(self, now: datetime):
        self.value = now

    def __call__(self) -> datetime:
        return self.value


class FakeClient:
    """Records outgoing API calls instead of talking to Soroush."""

    def __init__(self):
        self.sent = []       # (chat_id, text, reply_markup)
        self.edited = []     # (chat_id, message_id, text, reply_markup)
        self.documents = []  # (chat_id, filename, content, caption)
        self._next_id = 100

    def send_message(self, chat_id, text, reply_markup=None):
        self._next_id += 1
        self.sent.append((chat_id, text, reply_markup))
        return {"message_id": self._next_id}

    def edit_message_text(self, chat_id, message_id, text, reply_markup=None):
        self.edited.append((chat_id, message_id, text, reply_markup))

    def answer_callback_query(self, callback_query_id, text=None):
        pass

    def send_document(self, chat_id, filename, content, caption=None):
        self.documents.append((chat_id, filename, content, caption))


@pytest.fixture
def db():
    return Database(":memory:")


@pytest.fixture
def config():
    return Config(token="T", admin_ids=frozenset({"900"}))


@pytest.fixture
def clock():
    # Monday 2026-10-12 = 20 Mehr 1405
    return Clock(datetime(2026, 10, 12, 9, 0))


@pytest.fixture
def client():
    return FakeClient()
