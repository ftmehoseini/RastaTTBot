from unittest.mock import MagicMock

import pytest

from bot.soroush_api import SoroushAPIError, SoroushClient, inline_keyboard


def make_client(json_body, status=200):
    session = MagicMock()
    response = MagicMock(status_code=status, text="")
    response.json.return_value = json_body
    session.post.return_value = response
    return SoroushClient("TOKEN", "https://api.splus.ir/bot/", session=session), session


def test_call_builds_url_and_drops_none_params():
    client, session = make_client({"ok": True, "result": {"message_id": 7}})

    result = client.send_message(42, "hi")

    assert result == {"message_id": 7}
    url = session.post.call_args.args[0]
    assert url == "https://api.splus.ir/botTOKEN/sendMessage"
    assert session.post.call_args.kwargs["json"] == {"chat_id": 42, "text": "hi"}


def test_error_response_raises():
    client, _ = make_client({"ok": False, "error_code": 401, "description": "Unauthorized"})

    with pytest.raises(SoroushAPIError, match="getMe: 401 Unauthorized"):
        client.get_me()


def test_non_json_response_raises():
    client, session = make_client(None, status=502)
    session.post.return_value.json.side_effect = ValueError

    with pytest.raises(SoroushAPIError, match="HTTP 502"):
        client.get_me()


def test_get_updates_http_timeout_outlives_long_poll():
    client, session = make_client({"ok": True, "result": []})

    assert client.get_updates(offset=5, timeout=20) == []
    kwargs = session.post.call_args.kwargs
    assert kwargs["json"] == {"offset": 5, "timeout": 20}
    assert kwargs["timeout"] == 30


def test_inline_keyboard():
    assert inline_keyboard([[("A", "a"), ("B", "b")]]) == {
        "inline_keyboard": [
            [{"text": "A", "callback_data": "a"}, {"text": "B", "callback_data": "b"}]
        ]
    }


def test_send_document_uses_multipart():
    client, session = make_client({"ok": True, "result": {"message_id": 9}})

    client.send_document(42, "r.xlsx", b"PK..", caption="report")

    kwargs = session.post.call_args.kwargs
    assert session.post.call_args.args[0].endswith("/sendDocument")
    assert kwargs["files"] == {"document": ("r.xlsx", b"PK..")}
    assert kwargs["data"] == {"chat_id": "42", "caption": "report"}
    assert "json" not in kwargs


def test_reply_keyboard():
    from bot.soroush_api import reply_keyboard

    assert reply_keyboard([["A", "B"]]) == {
        "keyboard": [[{"text": "A"}, {"text": "B"}]],
        "resize_keyboard": True,
    }
