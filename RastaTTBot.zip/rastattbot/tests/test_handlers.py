from datetime import datetime

import pytest

from bot.handlers import BTN_FORGOT, BTN_IN, BTN_OUT, BTN_REPORT, BotHandlers

ME = 1


def msg(text, chat_id=ME):
    return {"update_id": 1, "message": {"message_id": 5, "chat": {"id": chat_id}, "from": {"id": chat_id}, "text": text}}


def cb(data, chat_id=ME):
    return {"update_id": 2, "callback_query": {"id": "q", "from": {"id": chat_id}, "data": data,
                                                "message": {"message_id": 50, "chat": {"id": chat_id}}}}


@pytest.fixture
def bot(client, db, config, clock):
    return BotHandlers(client, db, config, clock)


@pytest.fixture
def registered(bot, client):
    bot.handle_update(msg("/start"))
    bot.handle_update(msg("Ali Rezaei"))
    client.sent.clear()
    return bot


def last(client):
    return client.sent[-1][1]


def last_edit(client):
    return client.edited[-1][2]


def buttons(markup):
    return [b["callback_data"] for row in markup["inline_keyboard"] for b in row]


def test_registration(bot, client, db):
    bot.handle_update(msg("/start"))
    assert "نام و نام خانوادگی" in last(client)
    bot.handle_update(msg("Ali   Rezaei"))
    assert db.get_user(ME).full_name == "Ali Rezaei"
    assert "keyboard" in client.sent[-1][2]


def test_unregistered_user_cannot_check_in(bot, client, db):
    bot.handle_update(msg(BTN_IN))
    assert db.open_session(ME) is None
    assert "نام" in last(client)


def test_check_in_and_out(registered, client, clock, db):
    registered.handle_update(msg(BTN_IN))
    assert "ورود ثبت شد" in last(client) and "09:00" in last(client)
    clock.value = datetime(2026, 10, 12, 17, 30)
    registered.handle_update(msg(BTN_OUT))
    assert "خروج ثبت شد" in last(client) and "8:30" in last(client)


def test_forgotten_check_out_full_flow(registered, client, clock, db):
    # Checked in Sunday, forgot to check out.
    clock.value = datetime(2026, 10, 11, 8, 0)
    registered.handle_update(msg(BTN_IN))
    clock.value = datetime(2026, 10, 12, 9, 0)

    registered.handle_update(msg(BTN_FORGOT))
    assert "fg:k:out" in buttons(client.sent[-1][2])
    registered.handle_update(cb("fg:k:out"))
    months = buttons(client.edited[-1][3])
    assert months[0] == "fg:m:out:1405:7"
    registered.handle_update(cb("fg:m:out:1405:7"))
    days = buttons(client.edited[-1][3])
    assert "fg:d:out:1405:7:20" in days and "fg:d:out:1405:7:21" not in days  # no future days
    registered.handle_update(cb("fg:d:out:1405:7:19"))
    assert len([b for b in buttons(client.edited[-1][3]) if b.startswith("fg:h:")]) == 24
    registered.handle_update(cb("fg:h:out:1405:7:19:17"))
    assert "دقیقه" in last_edit(client)

    registered.handle_update(msg("abc"))
    assert "0 تا 59" in last(client)
    registered.handle_update(msg("۴۵"))  # Persian digits
    assert "17:45" in last(client)
    registered.handle_update(cb("fg:ok"))
    assert "خروج ثبت شد" in last_edit(client)
    [s] = db.sessions_between(datetime(2026, 10, 11).date(), datetime(2026, 10, 11).date(), ME)
    assert s.check_out == datetime(2026, 10, 11, 17, 45) and s.manual_out
    assert db.get_state(ME) == (None, {})


def test_stale_session_offers_shortcut_button(registered, client, clock):
    clock.value = datetime(2026, 10, 11, 8, 0)
    registered.handle_update(msg(BTN_IN))
    clock.value = datetime(2026, 10, 12, 9, 0)
    registered.handle_update(msg(BTN_IN))
    assert buttons(client.sent[-1][2]) == ["fg:d:out:1405:7:19"]


def test_forgotten_past_check_in_prompts_for_check_out(registered, client):
    registered.handle_update(cb("fg:h:in:1405:7:18:8"))
    registered.handle_update(msg("0"))
    registered.handle_update(cb("fg:ok"))
    assert "ورود ثبت شد" in last_edit(client)
    assert buttons(client.sent[-1][2]) == ["fg:d:out:1405:7:18"]


def test_cancel_and_expired_confirm(registered, client, db):
    registered.handle_update(cb("fg:h:in:1405:7:18:8"))
    registered.handle_update(msg("/cancel"))
    assert db.get_state(ME) == (None, {})
    registered.handle_update(cb("fg:ok"))
    assert "منقضی" in last_edit(client)


def test_report_menu_admin_only_rows(registered, client, bot):
    registered.handle_update(msg(BTN_REPORT))
    assert not any(b.startswith("rp:all") for b in buttons(client.sent[-1][2]))
    bot.handle_update(msg("/start", chat_id=900))
    bot.handle_update(msg("Boss", chat_id=900))
    bot.handle_update(msg(BTN_REPORT, chat_id=900))
    assert "rp:allx:m" in buttons(client.sent[-1][2])


def test_non_admin_cannot_get_team_report(registered, client):
    registered.handle_update(cb("rp:allx:m"))
    assert client.documents == []
    assert "مدیران" in last(client)


def test_reports(registered, client, clock):
    registered.handle_update(msg(BTN_IN))
    clock.value = datetime(2026, 10, 12, 17, 0)
    registered.handle_update(msg(BTN_OUT))
    registered.handle_update(cb("rp:me:w"))
    text = last(client)
    assert "Ali Rezaei" in text and "مجموع ساعت کار: 8:00" in text
    registered.handle_update(cb("rp:mex:m"))
    chat_id, filename, content, _ = client.documents[-1]
    assert filename.endswith(".xlsx") and content[:2] == b"PK"


def test_previous_month_period(bot):
    start, end, title = bot.period("pm")
    assert (start, end) == (datetime(2026, 8, 23).date(), datetime(2026, 9, 22).date())
    assert "شهریور" in title
