import io
from datetime import date, datetime

from openpyxl import load_workbook

from bot.db import Session, User
from bot.excel_export import build_workbook


def test_workbook_contents():
    users = [User("1", "Ali"), User("2", "Sara")]
    sessions = [
        Session(1, "1", datetime(2026, 10, 11, 8), datetime(2026, 10, 11, 16, 30), False, True),
        Session(2, "2", datetime(2026, 10, 12, 9), None, False, False),
    ]
    wb = load_workbook(io.BytesIO(build_workbook(users, sessions, date(2026, 10, 10), date(2026, 10, 12))))
    detail = list(wb["جزئیات"].values)
    assert detail[1] == ("Ali", "1405/07/19", "یکشنبه", "08:00", "16:30", "8:30", "بله")
    assert detail[2][4] == "ثبت نشده"
    summary = list(wb["خلاصه"].values)
    assert summary[1] == ("Ali", 1, "8:30", 0)
    assert summary[2] == ("Sara", 1, "0:00", 1)
    assert wb["جزئیات"].sheet_view.rightToLeft
