from datetime import datetime

import pytest

from bot.attendance import Attendance, AttendanceError

U = "1"


@pytest.fixture
def att(db):
    db.upsert_user(U, "Ali", datetime(2026, 10, 1))
    return Attendance(db, max_shift_hours=16)


def dt(day, h, m=0):
    return datetime(2026, 10, day, h, m)


def test_check_in_then_out(att, db):
    att.check_in(U, dt(12, 8))
    s = att.check_out(U, dt(12, 17, 30))
    assert s.duration.total_seconds() == 9.5 * 3600
    assert db.open_session(U) is None


def test_double_check_in_rejected(att):
    att.check_in(U, dt(12, 8))
    with pytest.raises(AttendanceError, match="قبلاً"):
        att.check_in(U, dt(12, 9))


def test_check_out_without_check_in(att):
    with pytest.raises(AttendanceError, match="ورودی"):
        att.check_out(U, dt(12, 17))


def test_night_shift_crosses_midnight(att):
    att.check_in(U, dt(12, 22))
    s = att.check_out(U, dt(13, 6))
    assert s.duration.total_seconds() == 8 * 3600


def test_stale_open_session_blocks_and_points_to_it(att):
    att.check_in(U, dt(11, 8))
    with pytest.raises(AttendanceError) as exc:
        att.check_in(U, dt(12, 8))
    assert exc.value.stale is not None
    assert exc.value.stale.check_in == dt(11, 8)
    with pytest.raises(AttendanceError) as exc:
        att.check_out(U, dt(12, 17))
    assert exc.value.stale is not None


def test_forgotten_check_out_closes_stale(att, db):
    att.check_in(U, dt(11, 8))
    att.add_forgotten_check_out(U, dt(11, 17), now=dt(12, 10))
    assert db.open_session(U) is None
    att.check_in(U, dt(12, 10))


def test_forgotten_check_out_validation(att):
    att.check_in(U, dt(11, 8))
    with pytest.raises(AttendanceError, match="آینده"):
        att.add_forgotten_check_out(U, dt(12, 11), now=dt(12, 10))
    with pytest.raises(AttendanceError, match="بعد از"):
        att.add_forgotten_check_out(U, dt(11, 7), now=dt(12, 10))
    with pytest.raises(AttendanceError, match="16"):
        att.add_forgotten_check_out(U, dt(12, 9), now=dt(12, 10))


def test_forgotten_check_in_past_day_then_check_out(att, db):
    att.add_forgotten_check_in(U, dt(10, 8), now=dt(12, 9))
    att.add_forgotten_check_out(U, dt(10, 16), now=dt(12, 9))
    [s] = db.sessions_between(dt(10, 0).date(), dt(10, 0).date(), U)
    assert s.manual_in and s.manual_out and s.duration.total_seconds() == 8 * 3600


def test_forgotten_check_in_corrects_late_button_press(att, db):
    att.check_in(U, dt(12, 10))
    s = att.add_forgotten_check_in(U, dt(12, 8, 15), now=dt(12, 10, 5))
    assert db.open_session(U).check_in == dt(12, 8, 15)
    assert s.manual_in


def test_forgotten_check_in_inside_existing_session_rejected(att):
    att.check_in(U, dt(11, 8))
    att.check_out(U, dt(11, 17))
    with pytest.raises(AttendanceError, match="هم‌پوشانی"):
        att.add_forgotten_check_in(U, dt(11, 12), now=dt(12, 9))


def test_forgotten_check_out_cannot_pass_next_session(att):
    att.add_forgotten_check_in(U, dt(11, 20), now=dt(12, 9))
    # A later session already exists
    att.db.add_check_in(U, dt(12, 2))
    att.db.set_check_out(att.db.next_session_after(U, dt(11, 20)).id, dt(12, 4))
    with pytest.raises(AttendanceError, match="قبل از ورود بعدی"):
        att.add_forgotten_check_out(U, dt(12, 3), now=dt(12, 9))
