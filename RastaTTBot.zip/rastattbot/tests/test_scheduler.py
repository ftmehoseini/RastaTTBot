from datetime import datetime

from bot.scheduler import Scheduler


def setup(client, db, config, clock):
    db.upsert_user("1", "Ali", datetime(2026, 10, 1))
    db.upsert_user("2", "Sara", datetime(2026, 10, 1))
    return Scheduler(client, db, config, clock)


def test_reminder_runs_once_on_workday_for_stale_sessions(client, db, config, clock):
    s = setup(client, db, config, clock)
    db.add_check_in("1", datetime(2026, 10, 11, 8, 0))   # forgot check-out yesterday
    db.add_check_in("2", datetime(2026, 10, 12, 8, 0))   # today, fine

    clock.value = datetime(2026, 10, 12, 9, 59)
    s.tick()
    assert client.sent == []

    clock.value = datetime(2026, 10, 12, 10, 0)
    s.tick()
    s.tick()
    assert [c for c, *_ in client.sent] == ["1"]
    assert "یادآوری" in client.sent[0][1]


def test_no_reminder_on_friday(client, db, config, clock):
    s = setup(client, db, config, clock)
    db.add_check_in("1", datetime(2026, 10, 14, 8, 0))
    clock.value = datetime(2026, 10, 16, 10, 0)  # Friday
    s.tick()
    assert client.sent == []


def test_missed_job_runs_within_grace_only(client, db, config, clock):
    s = setup(client, db, config, clock)
    db.add_check_in("1", datetime(2026, 10, 11, 8, 0))
    clock.value = datetime(2026, 10, 12, 14, 0)  # 4h late, outside grace
    s.tick()
    assert client.sent == []


def test_weekly_report_on_thursday(client, db, config, clock):
    s = setup(client, db, config, clock)
    sid = db.add_check_in("1", datetime(2026, 10, 13, 8, 0))
    db.set_check_out(sid, datetime(2026, 10, 13, 16, 0))
    clock.value = datetime(2026, 10, 15, 14, 0)  # Thursday
    s.tick()
    recipients = [c for c, *_ in client.sent]
    assert "1" in recipients and "2" in recipients and "900" in recipients
    assert [d[0] for d in client.documents] == ["900"]
    ali = next(t for c, t, _ in client.sent if c == "1")
    assert "8:00" in ali
